from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd


# ============================================================
# METALS SUPPORTED BY METALSENSE
# ============================================================

METALS = [
    "Pb",
    "Cd",
    "As",
    "Cr",
    "Hg",
    "Ni",
    "Cu",
    "Mn",
    "Se",
    "Sb",
    "Ba",
    "Fe",
    "Zn",
    "Al",
    "B",
]


# ============================================================
# LIMIT TYPES
# ============================================================

LIMIT_TYPES = {
    "MCL",
    "ACTION_LEVEL",
    "TREATMENT_TECHNIQUE",
    "GUIDELINE",
    "ACCEPTABLE_LIMIT",
    "PERMISSIBLE_LIMIT",
    "PARAMETRIC_VALUE",
    "INDICATOR_PARAMETER",
    "SECONDARY_STANDARD",
    "EFFLUENT_LIMIT",
    "SCREENING_VALUE",
}


# ============================================================
# STANDARD LIMIT
# ============================================================

@dataclass
class StandardLimit:
    value: float
    unit: str = "mg/L"

    limit_type: str = "REFERENCE"

    basis: str | None = None
    # health
    # aesthetic
    # operational
    # regulatory
    # discharge
    # screening

    effective_from: date | None = None
    effective_to: date | None = None

    conditions: Dict[str, Any] = field(default_factory=dict)

    source: str = ""
    source_reference: str = ""


# ============================================================
# STANDARD
# ============================================================

@dataclass
class Standard:
    id: str
    name: str

    country: str = ""
    agency: str = ""

    water_types: List[str] = field(default_factory=list)

    metals: List[str] = field(default_factory=list)

    # --------------------------------------------------------
    # Legacy structure
    #
    # Keep this because the existing ML/calculation engine
    # already expects:
    #
    # standard.limits["drinking water"]["Pb"]
    # --------------------------------------------------------

    limits: Dict[str, Dict[str, float]] = field(default_factory=dict)

    # --------------------------------------------------------
    # New detailed structure
    # --------------------------------------------------------

    # Multiple entries are required because a metal can have
    # different limits for different effective-date windows.
    limit_details: Dict[str, Dict[str, List[StandardLimit]]] = field(
        default_factory=dict
    )

    source: str = ""
    version: str = ""

    effective_from: date | None = None
    effective_to: date | None = None

    verification_status: str = "UNVERIFIED"


# ============================================================
# NORMALISATION
# ============================================================

def norm(value: Any) -> str:
    return re.sub(
        r"[^a-z0-9]",
        "",
        str(value).strip().lower(),
    )


def _normalise_metal(value: Any) -> str:
    value = str(value).strip()

    aliases = {
        "lead": "Pb",
        "pb": "Pb",

        "cadmium": "Cd",
        "cd": "Cd",

        "arsenic": "As",
        "as": "As",

        "chromium": "Cr",
        "cr": "Cr",

        "mercury": "Hg",
        "hg": "Hg",

        "nickel": "Ni",
        "ni": "Ni",

        "copper": "Cu",
        "cu": "Cu",

        "manganese": "Mn",
        "mn": "Mn",

        "selenium": "Se",
        "se": "Se",

        "antimony": "Sb",
        "sb": "Sb",

        "barium": "Ba",
        "ba": "Ba",

        "iron": "Fe",
        "fe": "Fe",

        "zinc": "Zn",
        "zn": "Zn",

        "aluminium": "Al",
        "aluminum": "Al",
        "al": "Al",

        "boron": "B",
        "b": "B",
    }

    return aliases.get(value.lower(), value)


# ============================================================
# BUILTIN STANDARD METADATA
# ============================================================

BUILTIN = [
    (
        "WHO",
        "WHO Guidelines for Drinking-water Quality",
        "",
        "WHO",
        ["drinking water"],
    ),

    (
        "BIS_CPCB",
        "BIS IS 10500 / CPCB",
        "India",
        "BIS / CPCB",
        [
            "drinking water",
            "groundwater",
            "freshwater",
            "industrial wastewater",
            "agricultural water",
        ],
    ),

    (
        "EPA",
        "EPA Safe Drinking Water Act",
        "United States",
        "EPA",
        ["drinking water"],
    ),

    (
        "EU_DWD",
        "EU Drinking Water Directive",
        "European Union",
        "European Union",
        ["drinking water"],
    ),

    (
        "GB_5749_2022",
        "GB 5749-2022",
        "China",
        "GB",
        ["drinking water"],
    ),

    (
        "JAPAN_WATERWORKS",
        "Waterworks Act Standards",
        "Japan",
        "Waterworks Act",
        ["drinking water"],
    ),

    (
        "HEALTH_CANADA",
        "Health Canada Guidelines",
        "Canada",
        "Health Canada",
        ["drinking water"],
    ),

    (
        "NHMRC",
        "NHMRC Drinking Water Guidelines",
        "Australia",
        "NHMRC",
        ["drinking water"],
    ),

    (
        "TRINKWV",
        "Trinkwasserverordnung",
        "Germany",
        "Trinkwasserverordnung",
        ["drinking water"],
    ),

    (
        "SANS_241",
        "SANS 241",
        "South Africa",
        "SANS",
        ["drinking water"],
    ),

    (
        "CONAMA_357_2005",
        "CONAMA Resolution 357/2005",
        "Brazil",
        "CONAMA",
        ["surface water"],
    ),

    (
        "SANPIN",
        "SanPiN",
        "Russia",
        "SanPiN",
        ["drinking water"],
    ),

    (
        "NOM_127_SSA1_2021",
        "NOM-127-SSA1-2021",
        "Mexico",
        "NOM",
        ["drinking water"],
    ),

    (
        "NEA",
        "NEA Standards",
        "Singapore",
        "NEA",
        ["drinking water"],
    ),

    (
        "MALAYSIA_MOH",
        "MOH Drinking Water Standards",
        "Malaysia",
        "MOH",
        ["drinking water"],
    ),

    (
        "DWSNZ",
        "DWSNZ",
        "New Zealand",
        "DWSNZ",
        ["drinking water"],
    ),

    (
        "SASO",
        "SASO Standards",
        "Saudi Arabia",
        "SASO",
        ["drinking water"],
    ),

    (
        "TS_266",
        "TS 266",
        "Turkey",
        "TS",
        ["drinking water"],
    ),

    (
        "NCH_409_1",
        "NCh 409/1",
        "Chile",
        "NCh",
        ["drinking water"],
    ),

    (
        "CAA",
        "Código Alimentario Argentino",
        "Argentina",
        "CAA",
        ["drinking water"],
    ),

    (
        "INDONESIA_MOH_492_2010",
        "MOH Regulation No. 492/2010",
        "Indonesia",
        "MOH",
        ["drinking water"],
    ),

    (
        "PNSDW",
        "PNSDW",
        "Philippines",
        "PNSDW",
        ["drinking water"],
    ),

    (
        "THAILAND_MOPH",
        "Ministry of Public Health Standards",
        "Thailand",
        "MOPH",
        ["drinking water"],
    ),

    (
        "QCVN_01_2009_BYT",
        "QCVN 01:2009/BYT",
        "Vietnam",
        "QCVN",
        ["drinking water"],
    ),

    # Restored country metadata. Numerical limits should only be populated
    # from verified source tables/CSV; metadata alone must never imply a
    # numerical standard exists.
    ("KOREA_WATER", "South Korea Drinking Water Standards", "South Korea", "Ministry of Environment", ["drinking water"]),
    ("UK_DW", "UK Drinking Water Standards", "United Kingdom", "DWI / UK regulators", ["drinking water"]),
    ("BANGLADESH_DW", "Bangladesh Drinking Water Standards", "Bangladesh", "Bangladesh standards authority", ["drinking water"]),
    ("PAKISTAN_DW", "Pakistan Drinking Water Standards", "Pakistan", "Pakistan standards authority", ["drinking water"]),
    ("EGYPT_DW", "Egypt Drinking Water Standards", "Egypt", "Egyptian regulatory authority", ["drinking water"]),
    ("NIGERIA_DW", "Nigeria Drinking Water Standards", "Nigeria", "Nigerian regulatory authority", ["drinking water"]),
    ("KENYA_DW", "Kenya Drinking Water Standards", "Kenya", "Kenyan regulatory authority", ["drinking water"]),
    ("ISRAEL_DW", "Israel Drinking Water Standards", "Israel", "Israeli Ministry of Health", ["drinking water"]),

    # Global framework metadata. These are intentionally present even when
    # this registry snapshot does not contain numerical limits for them.
    ("FAO_WHO_CODEX", "FAO/WHO Codex Alimentarius", "", "FAO / WHO", ["drinking water", "food"]),
    ("OECD", "OECD Water Quality Frameworks", "", "OECD", ["surface water", "groundwater"]),
    ("ISO_5667_10523", "ISO Water Sampling / pH Frameworks", "", "ISO", ["surface water", "groundwater", "drinking water"]),
    ("UNEP_GEMS_WATER", "UNEP GEMS/WATER", "", "UNEP", ["surface water", "freshwater"]),
    ("WORLD_BANK_IFC_EHS", "World Bank / IFC EHS Guidelines", "", "World Bank / IFC", ["industrial wastewater", "surface water"]),
    ("ICOLD", "ICOLD Water Quality Guidance", "", "ICOLD", ["surface water", "freshwater"]),
    ("EUROPEAN_COUNCIL", "European Council Water Quality Framework", "European Union", "European Council", ["drinking water"]),
    ("ASTM", "ASTM Water Quality Standards / Methods", "", "ASTM", ["water"]),
    ("ISO_IEC", "ISO/IEC Water Quality Standards", "", "ISO/IEC", ["water"]),
]


# ============================================================
# COUNTRY → STANDARD
# ============================================================

COUNTRY_STANDARDS = {
    norm(country): standard_id
    for country, standard_id in {
        "India": "BIS_CPCB",

        "United States": "EPA",
        "USA": "EPA",
        "US": "EPA",

        "European Union": "EU_DWD",
        "EU": "EU_DWD",

        "China": "GB_5749_2022",

        "Japan": "JAPAN_WATERWORKS",

        "Canada": "HEALTH_CANADA",

        "Australia": "NHMRC",

        "Germany": "TRINKWV",

        "South Africa": "SANS_241",

        "Brazil": "CONAMA_357_2005",

        "Russia": "SANPIN",

        "Mexico": "NOM_127_SSA1_2021",

        "Singapore": "NEA",

        "Malaysia": "MALAYSIA_MOH",

        "New Zealand": "DWSNZ",

        "Saudi Arabia": "SASO",

        "Turkey": "TS_266",

        "Chile": "NCH_409_1",

        "Argentina": "CAA",

        "Indonesia": "INDONESIA_MOH_492_2010",

        "Philippines": "PNSDW",

        "Thailand": "THAILAND_MOPH",

        "Vietnam": "QCVN_01_2009_BYT",

        "South Korea": "KOREA_WATER",
        "Korea": "KOREA_WATER",
        "Republic of Korea": "KOREA_WATER",
        "United Kingdom": "UK_DW",
        "UK": "UK_DW",
        "England": "UK_DW",
        "Scotland": "UK_DW",
        "Wales": "UK_DW",
        "Northern Ireland": "UK_DW",
        "Bangladesh": "BANGLADESH_DW",
        "Pakistan": "PAKISTAN_DW",
        "Egypt": "EGYPT_DW",
        "Nigeria": "NIGERIA_DW",
        "Kenya": "KENYA_DW",
        "Israel": "ISRAEL_DW",
    }.items()
}


# ============================================================
# GLOBAL FALLBACKS
# ============================================================

GLOBAL = [
    "FAO_WHO_CODEX",
    "OECD",
    "ISO_5667_10523",
    "UNEP_GEMS_WATER",
    "WORLD_BANK_IFC_EHS",
    "ICOLD",
    "EUROPEAN_COUNCIL",
    "ASTM",
    "ISO_IEC",
]


# ============================================================
# REGISTRY
# ============================================================

class StandardsRegistry:

    def __init__(self, directory="standards"):

        self.db = {
            standard_id: Standard(
                standard_id,
                name,
                country,
                agency,
                water_types,
                METALS.copy(),
                source=name,
            )
            for (
                standard_id,
                name,
                country,
                agency,
                water_types,
            ) in BUILTIN
        }

        self._builtin_limits()
        self._refresh_legacy_limits()

        self._load_csvs(Path(directory))
        self._refresh_legacy_limits()


    # ========================================================
    # HELPER
    # ========================================================

    def _add_limit(
        self,
        standard_id: str,
        water_type: str,
        metal: str,
        value: float,
        *,
        limit_type: str = "REFERENCE",
        basis: str | None = None,
        effective_from: date | None = None,
        effective_to: date | None = None,
        conditions: Dict[str, Any] | None = None,
        source: str = "",
        source_reference: str = "",
    ):

        standard = self.db[standard_id]

        metal = _normalise_metal(metal)

        detail = StandardLimit(
            value=value,
            unit="mg/L",
            limit_type=limit_type,
            basis=basis,
            effective_from=effective_from,
            effective_to=effective_to,
            conditions=conditions or {},
            source=source,
            source_reference=source_reference,
        )

        # New detailed representation: keep ALL versions instead of
        # overwriting an older/current/future entry for the same metal.
        bucket = standard.limit_details.setdefault(water_type, {})
        bucket.setdefault(metal, []).append(detail)

        # Legacy numeric representation remains available to the existing
        # calculation engine. It represents the currently applicable
        # version, not an arbitrary last-written version.
        today = date.today()
        if self._date_matches(detail, today):
            current = standard.limits.setdefault(water_type, {}).get(metal)
            if current is None:
                standard.limits[water_type][metal] = value
            else:
                existing_detail = self._select_detail(
                    bucket[metal],
                    today,
                )
                if existing_detail is detail:
                    standard.limits[water_type][metal] = value

        if metal not in standard.metals:
            standard.metals.append(metal)


    # ========================================================
    # DATE-AWARE HELPERS
    # ========================================================

    @staticmethod
    def _date_matches(
        limit: StandardLimit,
        sample_date: date,
    ) -> bool:
        if limit.effective_from and sample_date < limit.effective_from:
            return False
        if limit.effective_to and sample_date >= limit.effective_to:
            return False
        return True

    @classmethod
    def _select_detail(
        cls,
        candidates: List[StandardLimit],
        sample_date: date | None = None,
    ) -> StandardLimit | None:
        if not candidates:
            return None

        if sample_date is None:
            sample_date = date.today()

        applicable = [
            item for item in candidates
            if cls._date_matches(item, sample_date)
        ]

        if not applicable:
            return None

        # If multiple entries overlap, prefer the most recently effective
        # one. This prevents ambiguous rows from silently selecting an older
        # version.
        applicable.sort(
            key=lambda item: (
                item.effective_from is not None,
                item.effective_from or date.min,
            ),
            reverse=True,
        )
        return applicable[0]

    @staticmethod
    def _parse_date(value: Any) -> date | None:
        if value is None or pd.isna(value):
            return None
        parsed = pd.to_datetime(value, errors="coerce")
        if pd.isna(parsed):
            return None
        return parsed.date()

    # ========================================================
    # BUILTIN LIMITS
    # ========================================================

    def _builtin_limits(self):

        # ----------------------------------------------------
        # INDIA
        # ----------------------------------------------------

        india = {
            "Pb": .01,
            "Cd": .003,
            "As": .01,
            "Cr": .05,
            "Hg": .001,
            "Ni": .02,
            "Cu": .05,
            "Mn": .1,
            "Se": .01,
            "Sb": .005,
            "Ba": .7,
            "Fe": .3,
            "Zn": 5.0,
            "Al": .03,
            "B": .5,
        }

        for water_type in [
            "drinking water",
            "groundwater",
        ]:
            for metal, value in india.items():
                self._add_limit(
                    "BIS_CPCB",
                    water_type,
                    metal,
                    value,
                    limit_type="ACCEPTABLE_LIMIT",
                    basis="regulatory",
                    source="BIS IS 10500",
                )

        self.db["BIS_CPCB"].version = "IS 10500:2012 / current amendments"


        # ----------------------------------------------------
        # WHO
        # ----------------------------------------------------
        #
        # WHO's latest publication is the 4th edition
        # incorporating the 1st, 2nd and 3rd addenda (2026).
        #
        # Values below are retained from the established WHO
        # GDWQ chemical guidance where the 2026 searchable
        # source does not expose a changed value.
        #
        # DO NOT interpret missing values as zero.
        # ----------------------------------------------------

        who = {
            "Pb": .01,
            "Cd": .003,
            "As": .01,
            "Cr": .05,
            "Hg": .006,
            "Ni": .07,
            "Cu": 2.0,
            "Mn": .08,
            "Se": .04,
            "Sb": .02,
            "Ba": 1.3,
            "B": 2.4,
        }

        for metal, value in who.items():
            self._add_limit(
                "WHO",
                "drinking water",
                metal,
                value,
                limit_type="GUIDELINE",
                basis="health",
                source=(
                    "WHO Guidelines for Drinking-water Quality"
                ),
                source_reference=(
                    "4th edition + 1st, 2nd and 3rd addenda"
                ),
            )

        self.db["WHO"].version = (
            "4th edition + 1st, 2nd and 3rd addenda (2026)"
        )

        self.db["WHO"].verification_status = (
            "CURRENT_VERSION_METADATA"
        )


        # ----------------------------------------------------
        # USA EPA
        # ----------------------------------------------------

        epa = {
            "Pb": (
                .010,
                "ACTION_LEVEL",
                "regulatory",
            ),

            "Cd": (
                .005,
                "MCL",
                "health",
            ),

            "As": (
                .010,
                "MCL",
                "health",
            ),

            "Cr": (
                .100,
                "MCL",
                "health",
            ),

            "Hg": (
                .002,
                "MCL",
                "health",
            ),

            "Cu": (
                1.3,
                "ACTION_LEVEL",
                "regulatory",
            ),

            "Se": (
                .05,
                "MCL",
                "health",
            ),

            "Sb": (
                .006,
                "MCL",
                "health",
            ),

            "Ba": (
                2.0,
                "MCL",
                "health",
            ),
        }

        for metal, (
            value,
            limit_type,
            basis,
        ) in epa.items():

            self._add_limit(
                "EPA",
                "drinking water",
                metal,
                value,
                limit_type=limit_type,
                basis=basis,
                source="US EPA NPDWR",
                source_reference="40 CFR 141",
            )

        # Secondary standards
        for metal, value in {
            "Fe": .3,
            "Zn": 5.0,
        }.items():

            self._add_limit(
                "EPA",
                "drinking water",
                metal,
                value,
                limit_type="SECONDARY_STANDARD",
                basis="aesthetic",
                source="US EPA NSDWR",
                source_reference="40 CFR 143",
            )

        self.db["EPA"].version = (
            "NPDWR / NSDWR current regulatory tables"
        )


        # ----------------------------------------------------
        # EU DRINKING WATER DIRECTIVE
        # ----------------------------------------------------
        #
        # Directive (EU) 2020/2184 Annex I.
        #
        # Important:
        # Pb and Cr have transition dates.
        # ----------------------------------------------------

        eu_source = (
            "Directive (EU) 2020/2184, Annex I"
        )

        # Current Pb value
        self._add_limit(
            "EU_DWD",
            "drinking water",
            "Pb",
            .010,
            limit_type="PARAMETRIC_VALUE",
            basis="regulatory",
            effective_to=date(2036, 1, 12),
            source=eu_source,
            source_reference="Annex I Part B",
        )

        # Future Pb value
        self._add_limit(
            "EU_DWD",
            "drinking water",
            "Pb",
            .005,
            limit_type="PARAMETRIC_VALUE",
            basis="regulatory",
            effective_from=date(2036, 1, 12),
            source=eu_source,
            source_reference="Annex I Part B",
        )

        # Current Cr
        self._add_limit(
            "EU_DWD",
            "drinking water",
            "Cr",
            .050,
            limit_type="PARAMETRIC_VALUE",
            basis="regulatory",
            effective_to=date(2036, 1, 12),
            source=eu_source,
            source_reference="Annex I Part B",
        )

        # Future Cr
        self._add_limit(
            "EU_DWD",
            "drinking water",
            "Cr",
            .025,
            limit_type="PARAMETRIC_VALUE",
            basis="regulatory",
            effective_from=date(2036, 1, 12),
            source=eu_source,
            source_reference="Annex I Part B",
        )

        # Other EU chemical parameters
        eu_values = {
            "Cd": .005,
            "As": .010,
            "Hg": .001,
            "Ni": .020,
            "Cu": 2.0,
            "Se": .020,
            "Sb": .010,
            "B": 1.5,
        }

        for metal, value in eu_values.items():

            self._add_limit(
                "EU_DWD",
                "drinking water",
                metal,
                value,
                limit_type="PARAMETRIC_VALUE",
                basis="regulatory",
                source=eu_source,
                source_reference="Annex I Part B",
            )

        # EU special selenium condition
        se_detail = self._select_detail(
            self.db["EU_DWD"].limit_details["drinking water"]["Se"],
            date.today(),
        )
        if se_detail:
            se_detail.conditions = {
                "high_groundwater_geology": .030,
                "high_groundwater_geology_unit": "mg/L",
            }

        # EU special boron condition
        b_detail = self._select_detail(
            self.db["EU_DWD"].limit_details["drinking water"]["B"],
            date.today(),
        )
        if b_detail:
            b_detail.conditions = {
                "desalinated_water_predominant": 2.4,
                "high_boron_groundwater": 2.4,
                "conditional_unit": "mg/L",
            }

        # Indicator parameters
        for metal, value in {
            "Al": .200,
            "Fe": .200,
            "Mn": .050,
        }.items():

            self._add_limit(
                "EU_DWD",
                "drinking water",
                metal,
                value,
                limit_type="INDICATOR_PARAMETER",
                basis="operational",
                source=eu_source,
                source_reference="Annex I Part C",
            )

        self.db["EU_DWD"].version = (
            "Directive (EU) 2020/2184"
        )

        self.db["EU_DWD"].verification_status = (
            "PRIMARY_SOURCE_VERIFIED"
        )


        # ----------------------------------------------------
        # CHINA
        # ----------------------------------------------------

        china = {
            "Pb": .01,
            "Cd": .005,
            "As": .01,
            "Cr": .05,
            "Hg": .001,
            "Ni": .02,
            "Cu": 1.0,
            "Mn": .1,
            "Se": .01,
            "Sb": .005,
            "Ba": .7,
            "Fe": .3,
            "Zn": 1.0,
            "Al": .2,
            "B": .5,
        }

        for metal, value in china.items():
            self._add_limit(
                "GB_5749_2022",
                "drinking water",
                metal,
                value,
                limit_type="REGULATORY_LIMIT",
                basis="regulatory",
                source="GB 5749-2022",
            )

        self.db["GB_5749_2022"].version = "2022"


        # ----------------------------------------------------
        # JAPAN
        # ----------------------------------------------------

        japan = {
            "Pb": .01,
            "Cd": .003,
            "As": .01,
            "Cr": .02,
            "Hg": .0005,
            "Ni": .02,
            "Cu": 1.0,
            "Mn": .05,
            "Se": .01,
            "Sb": .02,
            "Fe": .3,
            "Zn": 1.0,
            "Al": .2,
            "B": 1.0,
        }

        for metal, value in japan.items():
            self._add_limit(
                "JAPAN_WATERWORKS",
                "drinking water",
                metal,
                value,
                limit_type="REGULATORY_LIMIT",
                basis="regulatory",
                source="Japan Waterworks Act",
            )


        # ----------------------------------------------------
        # CANADA
        # ----------------------------------------------------

        canada = {
            "Pb": .005,
            "Cd": .007,
            "As": .01,
            "Cr": .05,
            "Hg": .001,
            "Ni": .02,
            "Cu": 2.0,
            "Mn": .12,
            "Se": .05,
            "Sb": .006,
            "Ba": 2.0,
            "Fe": .3,
            "Zn": 5.0,
            "Al": .2,
            "B": 5.0,
        }

        for metal, value in canada.items():
            self._add_limit(
                "HEALTH_CANADA",
                "drinking water",
                metal,
                value,
                limit_type="GUIDELINE",
                basis="health",
                source="Health Canada Guidelines",
            )


        # ----------------------------------------------------
        # AUSTRALIA
        # ----------------------------------------------------

        australia = {
            "Pb": .01,
            "Cd": .002,
            "As": .01,
            "Cr": .05,
            "Hg": .001,
            "Ni": .02,
            "Cu": 2.0,
            "Mn": .5,
            "Se": .01,
            "Sb": .003,
            "Ba": 2.0,
            "Fe": .3,
            "Zn": 3.0,
            "Al": .2,
            "B": 4.0,
        }

        for metal, value in australia.items():
            self._add_limit(
                "NHMRC",
                "drinking water",
                metal,
                value,
                limit_type="GUIDELINE",
                basis="health",
                source="NHMRC Australian Drinking Water Guidelines",
            )


        # ----------------------------------------------------
        # SOUTH AFRICA
        # ----------------------------------------------------

        south_africa = {
            "Pb": .01,
            "Cd": .003,
            "As": .01,
            "Cr": .05,
            "Hg": .006,
            "Ni": .07,
            "Cu": 2.0,
            "Mn": .4,
            "Se": .04,
            "Sb": .02,
            "Ba": .7,
            "Fe": .3,
            "Zn": 5.0,
            "Al": .3,
            "B": 2.4,
        }

        for metal, value in south_africa.items():
            self._add_limit(
                "SANS_241",
                "drinking water",
                metal,
                value,
                limit_type="REGULATORY_LIMIT",
                basis="health",
                source="SANS 241",
            )


    # ========================================================
    # LEGACY LIMITS REFRESH
    # ========================================================

    def _refresh_legacy_limits(self):
        """Populate the legacy float map from today's applicable detail."""
        today = date.today()

        for standard in self.db.values():
            for context, metals in standard.limit_details.items():
                legacy_context = standard.limits.setdefault(context, {})

                for metal, candidates in metals.items():
                    if isinstance(candidates, StandardLimit):
                        candidates = [candidates]

                    detail = self._select_detail(candidates, today)
                    if detail is not None:
                        legacy_context[metal] = detail.value

    # ========================================================
    # CSV LOADER
    # ========================================================

    def _load_csvs(self, directory: Path):

        if not directory.exists():
            return

        for path in directory.glob("*.csv"):

            try:

                df = pd.read_csv(path)

                cols = {
                    norm(c): c
                    for c in df.columns
                }

                std_col = next(
                    (
                        cols[k]
                        for k in [
                            "standard",
                            "standardid",
                            "authority",
                            "framework",
                        ]
                        if k in cols
                    ),
                    None,
                )

                metal_col = next(
                    (
                        cols[k]
                        for k in [
                            "metal",
                            "parameter",
                            "analyte",
                            "pollutant",
                        ]
                        if k in cols
                    ),
                    None,
                )

                limit_col = next(
                    (
                        cols[k]
                        for k in [
                            "limit",
                            "permissiblelimit",
                            "referencevalue",
                            "value",
                            "standardvalue",
                        ]
                        if k in cols
                    ),
                    None,
                )

                water_col = next(
                    (
                        cols[k]
                        for k in [
                            "watertype",
                            "watercontext",
                            "context",
                            "scenario",
                        ]
                        if k in cols
                    ),
                    None,
                )

                effective_from_col = next(
                    (
                        cols[k]
                        for k in [
                            "effectivefrom",
                            "effective_from",
                            "validfrom",
                            "startdate",
                            "fromdate",
                        ]
                        if k in cols
                    ),
                    None,
                )

                effective_to_col = next(
                    (
                        cols[k]
                        for k in [
                            "effectiveto",
                            "effective_to",
                            "validto",
                            "enddate",
                            "todate",
                        ]
                        if k in cols
                    ),
                    None,
                )

                limit_type_col = next(
                    (
                        cols[k]
                        for k in [
                            "limittype",
                            "limit_type",
                            "type",
                        ]
                        if k in cols
                    ),
                    None,
                )

                basis_col = next(
                    (
                        cols[k]
                        for k in [
                            "basis",
                        ]
                        if k in cols
                    ),
                    None,
                )

                if not (
                    std_col
                    and metal_col
                    and limit_col
                ):
                    continue

                for _, row in df.iterrows():

                    sid = str(
                        row[std_col]
                    ).strip().upper()

                    metal = _normalise_metal(
                        row[metal_col]
                    )

                    try:
                        value = float(
                            row[limit_col]
                        )
                    except Exception:
                        continue

                    context = (
                        str(row[water_col]).strip()
                        if water_col
                        else "drinking water"
                    )

                    if sid not in self.db:

                        self.db[sid] = Standard(
                            sid,
                            sid,
                            metals=[],
                        )

                    self._add_limit(
                        sid,
                        context,
                        metal,
                        value,
                        limit_type=(
                            str(row[limit_type_col]).strip()
                            if limit_type_col
                            and not pd.isna(row[limit_type_col])
                            else "REFERENCE"
                        ),
                        basis=(
                            str(row[basis_col]).strip()
                            if basis_col
                            and not pd.isna(row[basis_col])
                            else None
                        ),
                        effective_from=(
                            self._parse_date(row[effective_from_col])
                            if effective_from_col
                            else None
                        ),
                        effective_to=(
                            self._parse_date(row[effective_to_col])
                            if effective_to_col
                            else None
                        ),
                        source=str(path),
                    )

                    self.db[sid].source = str(path)

            except Exception as exc:

                print(
                    f"[StandardsRegistry] "
                    f"Could not load {path}: {exc}"
                )


    # ========================================================
    # GET LIMITS
    # ========================================================

    def get_limits(
        self,
        standard: str,
        water_type: str,
        sample_date: date | datetime | None = None,
    ):
        standard_obj = self.db.get(str(standard).upper())
        if not standard_obj:
            return {}

        if isinstance(sample_date, datetime):
            sample_date = sample_date.date()

        target = norm(water_type)

        for context, limits in standard_obj.limit_details.items():
            if norm(context) != target:
                continue

            result = {}

            for metal, candidates in limits.items():
                detail = self._select_detail(
                    candidates,
                    sample_date,
                )
                if detail is not None:
                    result[metal] = detail.value

            return result

        # Backward-compatible fallback for standards loaded by older CSVs
        # or external code that only populated legacy limits.
        for context, limits in standard_obj.limits.items():
            if norm(context) == target:
                return dict(limits)

        return {}

    # ========================================================
    # GET DETAILED LIMIT
    # ========================================================

    def get_limit_detail(
        self,
        standard: str,
        water_type: str,
        metal: str,
        sample_date: date | datetime | None = None,
    ):
        standard_obj = self.db.get(str(standard).upper())
        if not standard_obj:
            return None

        if isinstance(sample_date, datetime):
            sample_date = sample_date.date()

        target = norm(water_type)
        metal = _normalise_metal(metal)

        for context, limits in standard_obj.limit_details.items():
            if norm(context) != target:
                continue

            candidates = limits.get(metal, [])

            # Compatibility with a malformed/legacy in-memory object.
            if isinstance(candidates, StandardLimit):
                candidates = [candidates]

            return self._select_detail(
                candidates,
                sample_date,
            )

        return None

    # ========================================================
    # SELECT STANDARD
    # ========================================================

    def select(
        self,
        country,
        water_type,
        metals,
        sample_date=None,
    ):

        country_key = norm(country)

        sid = COUNTRY_STANDARDS.get(
            country_key
        )

        metals = {
            _normalise_metal(m)
            for m in metals
        }

        # ----------------------------------------------------
        # Country-specific standard
        # ----------------------------------------------------

        if sid and sid in self.db:

            limits = self.get_limits(
                sid,
                water_type,
                sample_date,
            )

            available = (
                metals & set(limits)
            )

            if available:

                standard = self.db[sid]

                return {
                    "standard": sid,
                    "name": standard.name,
                    "level": "COUNTRY",
                    "calculation_standard": sid,
                    "reason": (
                        "Country-specific standard "
                        "matched context and supplied "
                        "metal limits."
                    ),
                    "matched_metals": sorted(
                        available
                    ),
                    "sample_date": (
                        str(sample_date)
                        if sample_date
                        else None
                    ),
                    "version": standard.version,
                }

        # ----------------------------------------------------
        # Global fallback
        # ----------------------------------------------------

        candidates = []

        for global_sid in GLOBAL:

            if global_sid not in self.db:
                continue

            limits = self.get_limits(
                global_sid,
                water_type,
                sample_date,
            )

            available = (
                metals & set(limits)
            )

            if available:

                score = (
                    len(available)
                    / max(len(metals), 1)
                )

                candidates.append(
                    (
                        score,
                        global_sid,
                    )
                )

        if candidates:

            _, selected_sid = max(
                candidates
            )

            standard = self.db[
                selected_sid
            ]

            return {
                "standard": selected_sid,
                "name": standard.name,
                "level": "GLOBAL",
                "calculation_standard": selected_sid,
                "reason": (
                    "Best available global "
                    "framework with numerical "
                    "limits for the selected "
                    "context and metals."
                ),
                "version": standard.version,
            }

        # ----------------------------------------------------
        # WHO fallback
        # ----------------------------------------------------

        standard = self.db["WHO"]

        return {
            "standard": "WHO",
            "name": standard.name,
            "level": "WHO_FALLBACK",
            "calculation_standard": "WHO",
            "reason": (
                "No suitable country-specific "
                "or global numerical standard "
                "was available; WHO was used "
                "as generalized fallback."
            ),
            "version": standard.version,
        }


    # ========================================================
    # COMPARE
    # ========================================================

    def compare(
        self,
        water_type,
        metal,
        sample_date=None,
    ):

        result = {}

        for sid in self.db:

            detail = self.get_limit_detail(
                sid,
                water_type,
                metal,
                sample_date,
            )

            result[sid] = (
                detail.value
                if detail
                else None
            )

        return result


    # ========================================================
    # METADATA
    # ========================================================

    def list_metadata(self):

        return [

            {
                "id": standard.id,

                "name": standard.name,

                "country": standard.country,

                "agency": standard.agency,

                "water_types": (
                    standard.water_types
                ),

                "metals": (
                    standard.metals
                ),

                "source": standard.source,

                "version": standard.version,

                "has_numeric_limits": bool(
                    standard.limits
                ),

                "verification_status": (
                    standard.verification_status
                ),

            }

            for standard in self.db.values()

        ]